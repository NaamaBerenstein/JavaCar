package javaProject;

import java.util.Arrays;

public class Car {

	private String firm;
	private String Model;
	private long year;
	private Radio radio;
	private Wheel[] wheels;

	public Car(String firm, String model, long year, Radio radio, Wheel[] wheels) {
		this.firm = firm;
		Model = model;
		this.year = year;
		this.radio = radio;
		this.wheels = wheels;
	}

	public String getFirm() {
		return firm;
	}

	public void setFirm(String firm) {
		this.firm = firm;
	}

	public String getModel() {
		return Model;
	}

	public void setModel(String model) {
		Model = model;
	}

	public long getYear() {
		return year;
	}

	public void setYear(long year) {
		this.year = year;
	}

	public Radio getRadio() {
		return radio;
	}

	public void setRadio(Radio radio) {
		this.radio = radio;
	}

	public Wheel[] getWheels() { 
		return wheels;
	}

	public void setWheels(Wheel[] wheels) {
		this.wheels = wheels;
	}

	@Override
	public String toString() {
		return "Car [firm=" + firm + ", Model=" + Model + ", year=" + year + ", radio=" + radio + ", wheels="
				+ Arrays.toString(wheels) + "]";
	}

	public boolean getRadioState() {
		return getRadio().isOn();
	}

	public String getRadioStation() {
		if (getRadio().isOn()) {
			int CurrentStation = getRadio().getActiveStation();
			String stationName = getRadio().getStation()[CurrentStation].getName();
			return stationName;
		} else
			return "Error 404";
	}

	public void printWheelCondition() {
		for (int i = 0; i < wheels.length; i++) {
			System.out.println(wheels[i].toString());
		}
	}

	public void puncture(int position) {
		getWheels()[position].setAirPressure(0);
		Wheel one = getWheels()[position];
		getWheels()[position] = getWheels()[4];
		getWheels()[4] = one;
	}
}