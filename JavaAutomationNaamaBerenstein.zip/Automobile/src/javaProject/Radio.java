package javaProject;

import java.util.Arrays;

public class Radio {

	private boolean isOn;
	private Stations[] station;
	private int ActiveStation;

	public Radio(Stations[] station) {
		this.isOn = false;
		this.station = station;
		this.ActiveStation = 0;
	}

	public boolean isOn() {
		return isOn;
	}

	public void setOn(boolean isOn) {
		this.isOn = isOn;
	}

	public Stations[] getStation() {
		return station;
	}

	public void setStation(Stations[] station) {
		this.station = station;
	}

	public int getActiveStation() {
		return ActiveStation;
	}

	public void setActiveStation(int activeStation) {
		ActiveStation = activeStation;
	}

	@Override
	public String toString() {
		return "Radio [isOn=" + isOn + ", station=" + Arrays.toString(station) + ", ActiveStation=" + ActiveStation
				+ "]";
	}

}
