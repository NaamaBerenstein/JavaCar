package javaProject;

public class Main {

	public static void main(String[] args) {
	    Wheel[] wheels = new Wheel[5];
	    wheels[0] = new Wheel(32);
	    wheels[1] = new Wheel(32);
	    wheels[2] = new Wheel(32);
	    wheels[3] = new Wheel(32);
	    wheels[4] = new Wheel(32);

	    Stations[] stations = new Stations[3];
	    stations[0] = new Stations("Jazz FM", 91);
	    stations[1] = new Stations("Classic FM", 91);
	    stations[2] = new Stations("Beat FM", 91);

	    Radio radio = new Radio(stations); 
	    
	    Car fiat = new Car("fiat", "punto", 2020, radio, wheels);
	    
	    System.out.println(fiat.getModel() + "\n" + fiat.toString());
	    System.out.println(fiat.getRadioState());
	    System.out.println(fiat.getRadioStation());
	    fiat.getRadio().setOn(true);
	    System.out.println(fiat.getRadioState());
	    System.out.println(fiat.getRadioStation());
	    fiat.puncture(3);
	    fiat.printWheelCondition();
	}
}