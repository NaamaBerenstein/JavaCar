package javaProject;


public class Wheel {

	private int airPressure;

	public Wheel(int airPressure) {
		this.airPressure = airPressure;
	}

	public int getAirPressure() {
		return airPressure;
	}

	public void setAirPressure(int airPressure) {
		this.airPressure = airPressure;
	}

	@Override
	public String toString() {
		return "Wheel [airPressure=" + airPressure + "]";
	}

}
